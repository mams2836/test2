package kott.classes.model;

import java.util.ArrayList;

public class SubjectModel {
	
	private int subjectId;
	private String subjectName;
	private float credits;
	private int courseId;
	private int semId;
	private String courseName;
	private String semesterName;
	private ArrayList<String> courselist;
	private ArrayList<String> semList;	
	private ArrayList<SubjectModel> modelList;
	
	public SubjectModel() {
		super();		
	}
	//getter and setter
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public float getCredits() {
		return credits;
	}
	public void setCredits(float credits) {
		this.credits = credits;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getSemId() {
		return semId;
	}
	public void setSemId(int semId) {
		this.semId = semId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getSemesterName() {
		return semesterName;
	}
	public void setSemesterName(String semesterName) {
		this.semesterName = semesterName;
	}
	public ArrayList<String> getCourselist() {
		return courselist;
	}
	public void setCourselist(ArrayList<String> courselist) {
		this.courselist = courselist;
	}
	public ArrayList<String> getSemList() {
		return semList;
	}
	public void setSemList(ArrayList<String> semList) {
		this.semList = semList;
	}
	public ArrayList<SubjectModel> getModelList() {
		return modelList;
	}
	public void setModelList(ArrayList<SubjectModel> modelList) {
		this.modelList = modelList;
	}
	

}
