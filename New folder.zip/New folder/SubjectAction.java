package kott.classes.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import kott.classes.model.SubjectModel;
import kott.classes.utility.DBConnection;

public class SubjectAction extends ActionSupport implements ModelDriven<SubjectModel>,Preparable {
	
	/**
	 * @author Mamatha K.P
	 */
	private static final long serialVersionUID = 1L;
	private SubjectModel subject = null;
	
	Connection con;

	@Override
	public SubjectModel getModel() {
		return subject;
	}

	@Override
	public void prepare() throws Exception {
		subject = new SubjectModel();
		
	}
	
	//add new subject
	public String addSub() throws ClassNotFoundException, SQLException {
		con = DBConnection.getConnection();
		System.out.println("inside subject add VALUES :"+subject.getSubjectId());
		System.out.print(" "+subject.getSubjectName()+" "+subject.getCourseId()+" "+subject.getSemId()+" "+subject.getCredits());
		//select course
		String selectCou = "SELECT course_id FROM COURSE WHERE course_name=?";
		PreparedStatement psCou = con.prepareStatement(selectCou);
		psCou.setString(1, subject.getCourseName());
		ResultSet rs = psCou.executeQuery();
		while(rs.next()) {
			System.out.println("Course ID :"+rs.getInt(1));
			subject.setCourseId(rs.getInt(1));
		}
		
		//select semester
		String selectSem = "SELECT semester_id FROM SEMESTER WHERE semester_name=?";
		PreparedStatement psSem = con.prepareStatement(selectSem);
		psSem.setString(1, subject.getSemesterName());
		ResultSet rsSem = psSem.executeQuery();
		while(rsSem.next()) {
			System.out.println("Course ID :"+rsSem.getInt(1));
			subject.setCourseId(rsSem.getInt(1));
		}
		
		String subjectAdd = "INSERT INTO SUBJECT(subject_name,course_id,sem_id,credits) VALUES(?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(subjectAdd);
		ps.setString(1, subject.getSubjectName());
		ps.setInt(2, subject.getCourseId());
		ps.setInt(3, subject.getSemId());
		ps.setFloat(4, subject.getCredits());
		ps.executeUpdate();
		
		return SUCCESS;
	}
	//delete subject
	public String deleteSub() {
		return SUCCESS;
	}
	//edit subject
	public String editSub() {
		return SUCCESS;
	}
	
}
