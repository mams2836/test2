package kott.classes.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

import kott.classes.model.SemesterModel;
import kott.classes.utility.DBConnection;

public class SemesterAction extends ActionSupport implements ModelDriven<SemesterModel>,Preparable{
	
	/**
	 * @author Mamatha K.P
	 */
	private static final long serialVersionUID = 1L;
	private SemesterModel semModel = null;
	Connection con;

	@Override
	public SemesterModel getModel() {
		return semModel;
	}
	
	//to add new semester
	public String addSem() throws ClassNotFoundException, SQLException {
		System.out.println("inside add Semester");
		try {
		String name = semModel.getSemesterName();
		con = DBConnection.getConnection();
		String insertSem = "INSERT INTO SEMESTER(semester_name) VALUES(?)";
		PreparedStatement ps = con.prepareStatement(insertSem);
		ps.setString(1, name);
		ps.executeUpdate();
		return SUCCESS;
		}finally {
			con.close();
		}
	}
	
	//delete semester
	public String deleteSem() throws ClassNotFoundException, SQLException {
		con = DBConnection.getConnection();
		
		System.out.println("inside delete Semester");
		try {
			String delete = "DELETE FROM SEMESTER WHERE semester_id=?";
			PreparedStatement ps = con.prepareStatement(delete);
			ps.setInt(1, semModel.getId());
			ps.executeUpdate();
		}finally {
			con.close();
		}
		return SUCCESS;
	}
	
	//edit semester
	public String editSem() throws ClassNotFoundException, SQLException {
		semModel.setId(semModel.getId());
		con = DBConnection.getConnection();
		String select = "UPDATE SEMESTER SET semester_name=? WHERE semester_id=?";
		PreparedStatement ps = con.prepareStatement(select);
		ps.setString(1, semModel.getSemesterName());
		ps.setInt(2, semModel.getId());
		ps.executeUpdate();
		return SUCCESS;		
	}

	@Override
	public void prepare() throws Exception {
		semModel = new SemesterModel();		
	}

}
